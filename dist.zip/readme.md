## Acode Ayu Mirage Theme

Acode Ayu Mirage is a plugin designed for the Acode text editor, based on the popular Ayu Mirage VS Code theme. This plugin is perfect for developers who are looking for a sleek and modern look and feel for their code editor.

> Bug Report - [Click here](https://github.com/bajrangCoder/acode-ayu-mirage-theme)

> Any improvement - [Click here](https://github.com/bajrangCoder/acode-ayu-mirage-theme)